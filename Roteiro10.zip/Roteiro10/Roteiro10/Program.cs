﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        private static void Main(string[] args)
        {
            /* 3. Ler  duas  matrizes  A  e  B  de  dimensões  4x4,  de  elementos  inteiros,  calcular  e 
           imprimir  a  matriz  C  que  é  a  soma  de  cada  elemento  das  posições  correspondentes 
           das duas matrizes anteriores. */

                int[,] A = new int[4, 4];
                int[,] B = new int[4, 4];
                int[,] C = new int[4, 4];

                LeMatriz(A);
                LeMatriz(B);
                for (int i = 0; i < A.GetLength(0); i++)
                    for (int j = 0; j < A.GetLength(1); j++)
                        C[i, j] = A[i, j] + B[i, j];
                ImprimeMatriz(C);
            

            void LeMatriz(int[,] Matriz)
            {
                for (int i = 0; i < Matriz.GetLength(0); i++)
                    for (int j = 0; j < Matriz.GetLength(1); j++)
                    {
                        Console.WriteLine("[{0}, {1}] = ", i, j);
                        Matriz[i, j] = int.Parse(Console.ReadLine());
                    }
            }
            void ImprimeMatriz(int[,] c)
            {
                int i, j;
                for (i = 0; i < C.GetLength(0); i++)
                    for (j = 0; j < C.GetLength(1); j++)
                        Console.WriteLine(A[i, j] + "\t");
                        Console.WriteLine();
            }
        }
    }
}


class Program2
    {
         void Main()
        {
            /* 4. Ler duas matrizes A e B de dimensões 4x4, de elementos inteiros, calcular a média 
           dos  valores  de  cada  matriz.  Se  você  for  esperto  faça  uma  função  que  calcule  que 
           execute esse cálculo. */

            int[,] A = new int[4, 4];
            int[,] B = new int[4, 4];
            int[,] C = new int[4, 4];

            LeMatriz(A);
            LeMatriz(B);
            LeMedia(A);
            LeMedia(B);

            void LeMatriz(int[,] Matriz)
            {
                for (int i = 0; i < A.GetLength(0); i++)
                    for (int j = 0; j < A.GetLength(1); j++)
                    {
                        Console.WriteLine("[{0}, {1}]", i, j);
                        Matriz[i, j] = int.Parse(Console.ReadLine());
                    }
            }

            void LeMedia(int[,] Matriz)  // Calculo da media dos elementos de cada coluna //
            {
                int somaColuna = 0;
                double media;
                for (int c = 0; c < A.GetLength(1); c++)
                {
                    for (int i = 0; i < A.GetLength(0); i++)
                        for (int j = 0; j < A.GetLength(1); j++)
                        {
                            somaColuna = somaColuna + A[i, j];
                        }
                    media = (double)somaColuna / A.GetLength(0);  //numero de linas
                    Console.WriteLine("Soma dos elementos da Coluna {0}:", somaColuna);
                    Console.WriteLine("Media dos elemetos da coluna {1}:", media);
                }
            }

        }
    }

class Program3
{
    void Main()
    {
        /*  5.Calcule  e imprima  a soma  dos elementos  da diagonal  principal e  da diagonal
       secundária da matriz C. */

        int[,] A = new int[3, 3];
        int[,] B = new int[3, 3];
        int[,] C = new int[3, 3];
        int[,] D = new int[3, 3];

        int[,] E = new int[3, 3];


        LeMatriz(A);
        LeMatriz(B);
        SomaMatrizes(A, B, C);
        ImprimeMatriz(C, "Soma das Matrizes");
        Console.WriteLine("Soma da diagonal principal = " + SomaDiagonal(C));
        Console.WriteLine("Soma da diagonal secundária = " + SomaDiagonalSecundaria(C));
        TranspoeMatriz(C, D);
        ImprimeMatriz(D, "Matriz da soma transposta"); ;
        MatrizMaior(A, B, E);
        ImprimeMatriz(E, " Matriz dos maiores valores");
    }

        void LeMatriz(int[,] Matriz) //LE MATRIZES//
        {
            for (int i = 0; i < Matriz.GetLength(0); i++)
                for (int j = 0; j < Matriz.GetLength(1); j++)
                {
                    Console.WriteLine("[{0}, {1}] = ", i, j);
                    Matriz[i, j] = int.Parse(Console.ReadLine());
                }
        }
        void SomaMatrizes(int[,] A, int[,] B, int[,] C) //SOMA DE MATRIZES//
        {
            for (int i = 0; i < A.GetLength(0); i++)
                for (int j = 0; j < A.GetLength(1); j++)
                {
                    C[i, j] = A[i, j] + B[i, j];
                }
        }
        int SomaDiagonal(int[,] Matriz)       // SOMAR NA DIAGONAL PRINCIPAL //
        {
            int i, soma = 0;
            for (i = 0; i < Matriz.GetLength(0); i++)     // MATRIZ QUADRADA //
                soma = soma + Matriz[i, i];
            return soma;
        }
        int SomaDiagonalSecundaria(int[,] Matriz)
        {
            int j, soma = 0;
            for (j = 0; j < Matriz.GetLength(1); j++)
                soma = soma + Matriz[j, j];
            return soma;
        }
        void ImprimeMatriz(int[,] A, String mensagem)
        {
            int i, j;
            for (i = 0; i < A.GetLength(0); i++)
                for (j = 0; j < A.GetLength(1); j++)
                {
                    Console.WriteLine(A[i, j] + "\t");
                    Console.WriteLine();
                }
        }

        /* 6. Calcule e imprima a matriz D que é a transposta de C. */

        void TranspoeMatriz(int[,] A, int[,] T)   // TRANSPOSICAO //
        {
            for (int i = 0; i <A.GetLength(0); i++)
                for (int j = 0; j < A.GetLength(1); j++)
                {
                    T[i, j] = A[j, i];
                }
        }

        /* 7. Calcule  e  imprima  a  matriz  E,  onde  cada  elemento  de  E  contém  o  maior  elemento 
da respectiva posição de A e B ( E[i, j] = MAIOR(A[i, j], B[i, j] ).  */
         
        void MatrizMaior(int[,] A, int[,] B, int[,] M)
        {
            int i, j;
            for (i = 0; i < A.GetLength(0); i++)
                for (j = 0; j < A.GetLength(1); j++)
                {
                    if (A[i, j] > B[i, j])
                    {
                        M[i, j] = A[i, j];
                    }
                    else
                    {
                        M[i, j] = B[i, j];
                    }
                }
        }

    }

class Program4
{
    void Main()
    {
        /* 8. Faça  uma  função  que  imprima  apenas  os  valores  da  diagonal  principal  para  baixo. 
Exemplo:  suponha que tenhamos a seguinte matriz 4 x 4:  */

       
        int [,] Matriz = { { 1, 2, 3, 4 }, { 5, 6, 7, 8 }, { 9, 0, 1, 2 }, { 3, 4, 5, 6 } };
        ImprimeMatriz(Matriz);

    }
    void ImprimeMatriz(int[,] Matriz)  // DIAGONAL PRINCIPAL // ONDE A LINHA == COLUNA //
    {
        int i, soma = 0;
        for ( i = 0; i < Matriz.GetLength(0); i++) // MATRIZ QUADRADA
            soma = soma + Matriz[i, i];

    }
}
class Program5
{
    void Main()
    {
        /* 9. Faça  uma  função  que  imprima  apenas  os  valores  da  diagonal  principal  e  acima. 
Exemplo:   */

        int[,] matriz = { { 1, 2, 3, 4 }, { 0, 6, 7, 8 }, { 0, 0, 1, 2 }, { 0, 0, 0, 6 } };
        
    }

    void ImprimeMatriz( int [,] A, String mensagem)
    {
        int i;    // DIAGONAL PRINCIPAL //
        Console.WriteLine(mensagem);
        for ( i = 0; i < A.GetLength(0); i++) ;
        Console.Write(A[i, i] + "\t");
        Console.WriteLine(); 
    }
}




 



