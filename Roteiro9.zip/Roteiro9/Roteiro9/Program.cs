﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Roteiro9
{
    /*3. Em uma cidade sabe-se que, em janeiro de um certo ano, não ocorreu temperatura inferior a 
15°C, nem superior a 40°C.  
Faça um programa que leia as temperaturas diárias (dos 10 primeiros dias) calcule e imprima: 
a) A menor e a maior temperatura ocorrida 
b) A temperatura média 
c) Em quais dias a temperatura foi inferior a temperatura média. */
    class Program1
    {
        static void Main(string[] args)
        {
            int i;

            int[] dias = new int[10] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int[] temperatura = new int[10];

        }



    

/*4. Faça um programa que defina um temperatura de 120 caracteres, incluindo brancos e: 
• Calcule e imprima quantos brancos existem na frase 
• Calcule e imprima quantas vezes aparece a letra P (maiúscula ou minúscula) 
• Dada  uma  letra  qualquer  fornecida  pelo  teclado,  imprimir  a  primeira  vez  que  ela  aparece  na 
frase. 
class Program2
{
    static void Main (String[] Args)
    {
        
        String[] caracteres = new string[120];

        brancos(caracteres);

        void brancos (String[] temperatura )
        {
          for ( int i = 0; i < caracteres.Length; i++)
            {
                Console.WriteLine("Digite uma frase:");
                caracteres[i] = Console.ReadLine();
          
            }
        }


    }
} */

